﻿using System;
using System.Runtime.Serialization;

namespace MessageLib
{
    [Serializable]
    public class Message
    {
        public Message(string content, DateTime send)
        {
            Content = content;
            SendDate = send;
        }

        public string Content { get; set; }

        public DateTime SendDate { get; set; }

        public virtual DateTime ReceiveDate => SendDate.AddSeconds(1);

        public override string ToString()
            => $"Mail: Content = {Content}, SendDate = {SendDate:yyyy:MM:dd HH:mm:ss}, ReceiveDate = {ReceiveDate:yyyy:MM:dd HH:mm:ss}";
    }
}
