﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;

namespace MessageLib
{
    [Serializable]
    public class MessageBox
    {
        public List<Message> messages = new List<Message>();

        public IEnumerator<Message> GetEnumerator()
        {
            var message = from m in messages
                          orderby m.ReceiveDate
                          select m;

            return message.GetEnumerator();
        }

        public void ReceiveMail(Message message) 
            => messages.Add(message);
    }
}
