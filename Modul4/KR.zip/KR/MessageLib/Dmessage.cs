﻿using System;
using System.Runtime.Serialization;

namespace MessageLib
{
    [Serializable]
    public class Dmessage : Message
    {
        public Dmessage(string content, DateTime send, int hours) : base(content, send)
        {
            Hours = hours;
        }

        public int Hours { get; set; }

        public override DateTime ReceiveDate => SendDate.AddHours(-Hours);

        public override string ToString()
            => $"D-Message: Content = {Content}, SendDate = {SendDate:yyyy-MM-dd HH:mm:ss}, Hours = {Hours}, ReceiveDate = {ReceiveDate:yyyy-MM-dd HH:mm:ss}";
    }
}
