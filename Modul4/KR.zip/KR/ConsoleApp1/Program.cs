﻿using MessageLib;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    public class Program
    {
        private static Random rnd = new Random();

        public static void Main()
        {
            string filePath = "messageBox.json";
            do
            {
                Console.Clear();
                try
                {
                    int n = GetInt();
                    var box = new MessageBox();
                    for (int i = 0; i < n; i++)
                        box.ReceiveMail(new Message(GetMessage(rnd.Next(5, 101)), DateTime.Now));

                    for (int i = 0; i < n / 2; i++)
                        box.ReceiveMail(new Dmessage(GetMessage(rnd.Next(5, 37)), DateTime.Now, rnd.Next(1, 1001)));

                    foreach (var item in box)
                        Console.WriteLine(item);

                    JSONSerialization(filePath, box);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }

                Console.WriteLine("\n\nTo exit press Escape key\nTo continue press any key . . .");
            } while (Console.ReadKey().Key != ConsoleKey.Escape);
        }

        private static void JSONSerialization(string filePath, MessageBox box)
        {
            var formatter = new DataContractJsonSerializer(typeof(MessageBox), new Type[] { typeof(Message), typeof(Dmessage) });

            using (FileStream fs = new FileStream(filePath, FileMode.OpenOrCreate))
                formatter.WriteObject(fs, box);
        }

        public static int GetInt(string message = "Input n: ", int lowerBound = 10, int upperBound = 1000)
        {
            int number;
            Console.Write(message);
            while (!int.TryParse(Console.ReadLine(), out number)
                || number < lowerBound || number > upperBound)
                Console.WriteLine($"Please input integer number in [{lowerBound}, {upperBound}]");

            return number;
        }


        private static string GetMessage(int length)
        {
            string letters = "qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM1234567890 ";
            StringBuilder stringBuilder = new StringBuilder();
            int wordLength = rnd.Next(length + 1);
            for (int j = 0; j < wordLength; j++)
                stringBuilder.Append(letters[rnd.Next(letters.Length)]);
            
            return $"{stringBuilder}";
        }
    }
}
