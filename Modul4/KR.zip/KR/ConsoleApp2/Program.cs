﻿using MessageLib;
using System;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Json;

namespace ConsoleApp2
{
    public class Program
    {

        public static void Main()
        {
            string filePath = "messageBox.json";
            do
            {
                Console.Clear();
                try
                {
                    var box = JSONDeserialize(filePath);
                    FirstLinq(box);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }

                Console.WriteLine("\n\nTo exit press Escape key\nTo continue press any key . . .");
            } while (Console.ReadKey().Key != ConsoleKey.Escape);
        }

        private static void FirstLinq(MessageBox box)
        {
            var min = (from m in box.messages
                       where m is Message
                       select m.ReceiveDate).Min();

            var linq = (from m in box.messages
                        where m.Content.Length > 20
                        where m is Dmessage
                        where m.ReceiveDate < min
                        select m).ToList();

            Console.WriteLine("First linq result:");
            foreach (var item in linq)
                Console.WriteLine(item);
        }

        public static MessageBox JSONDeserialize(string filePath)
        {
            var formatter = new DataContractJsonSerializer(typeof(MessageBox), new Type[] { typeof(Message), typeof(Dmessage) });
            MessageBox box;
            using (FileStream fs = new FileStream(filePath, FileMode.OpenOrCreate))
                box = (MessageBox)formatter.ReadObject(fs);

            return box;
        }
    }
}
