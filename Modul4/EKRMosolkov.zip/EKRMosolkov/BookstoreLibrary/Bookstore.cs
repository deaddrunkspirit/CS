﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace BookstoreLibrary
{

    [Serializable]
    public class Bookstore<T> : IEnumerable<T>
    {
        private List<T> items = new List<T>();

        public void Add(T item) => items.Add(item);

        public IEnumerator<T> GetEnumerator()
        {
            foreach (var item in items)
                yield return item;
        }

        IEnumerator IEnumerable.GetEnumerator()
            => GetEnumerator();
    }

}
