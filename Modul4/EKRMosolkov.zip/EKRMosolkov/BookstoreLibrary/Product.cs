﻿using System;

namespace BookstoreLibrary
{
    [Serializable]
    public class Product : IComparable<Product>
    {
        public double Price { get; set; }

        public string Title { get; set; }

        public Product(double price, string title)
        {
            if (price <= 0)
                throw new ArgumentException("Price must be positive!");
            if (title == "" || title == null)
                throw new ArgumentException("Invalid Title name");
            Title = title;
            Price = price;
        }


        public static explicit operator double(Product product)
            => product.Price;

        public override string ToString()
            => $"Price {Price:f2}.";

        public int CompareTo(Product other)
            => Price.CompareTo(other.Price);
    }

}
