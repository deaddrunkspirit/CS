﻿using System;
using System.Linq;

namespace BookstoreLibrary
{
    [Serializable]
    public class Book : Product
    {
        public short NumberOfPages { get; set; }
        public short Year { get; set; }
        public double Rating { get; set; }

        public Book(double price, string title, short year, short pages, double raiting) : base(price, title)
        {
            if (year < 1990 || year > 2020)
                throw new ArgumentException("Invalid Year value!");
            if (pages <= 0)
                throw new ArgumentException("Invalid page number!");
            if (raiting >= 5 || raiting < 0)
                throw new ArgumentException("Invalid raiting value!");

            Year = year;
            NumberOfPages = pages;
            Rating = raiting;
        }

        public string GetShortInfo() 
            => $"{NumberOfPages}.{Year}.{UniqeSymbols(Title)}.{(int)(Rating * 100)}";

        /// <summary>
        /// Gets uniqe symbols from book's title except space
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        private int UniqeSymbols(string str)
            => (str.Trim().GroupBy(x => x)).Count();

        public override string ToString()
            => base.ToString() + GetShortInfo();
    }

}
