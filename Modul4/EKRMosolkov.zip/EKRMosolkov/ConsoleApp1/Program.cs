﻿using BookstoreLibrary;
using System;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;

namespace ConsoleApp1
{
    public class Program
    {
        private const string FilePath = "../../../books.json";

        private static Random rnd = new Random();

        public static void Main()
        {
            do
            {
                Console.Clear();
                try
                {
                    var books = new Bookstore<Product>();
                    int number = GetInt();
                    for (int i = 0; i < number; i++)
                        try
                        {
                            books.Add(GenerateBook());
                        }
                        catch (ArgumentException e)
                        {
                            Console.WriteLine(e.Message);
                            i--;
                            continue;
                        }
                        catch (InvalidCastException)
                        {
                            Console.WriteLine("Error casting short to int!");
                            i--;
                            continue;
                        }

                    books.Add(new Product(1, "Товар1"));

                    foreach (var book in books)
                        Console.WriteLine(book);
                    try
                    {
                        JSONSerialization(FilePath, books);
                    }
                    catch (SerializationException)
                    {
                        Console.WriteLine("Error during serialization . . .");
                    }
                    catch (IOException)
                    {
                        Console.WriteLine($"Error working with file {FilePath}");
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }

                Console.WriteLine("\n\nTo exit press Escape key" +
                    "\nTo continue press any key . . .");
            } while (Console.ReadKey().Key != ConsoleKey.Escape);
        }

        /// <summary>
        /// This method serialize Bookstore to json document
        /// </summary>
        /// <param name="path"></param>
        /// <param name="serializableObject"></param>
        private static void JSONSerialization(string path, Bookstore<Product> serializableObject)
        {
            var formatter = new DataContractJsonSerializer(typeof(Bookstore<Product>), new Type[] { typeof(Product), typeof(Book) });
            using (var fs = new FileStream(path, FileMode.Create))
                formatter.WriteObject(fs, serializableObject);

            Console.WriteLine("Serialization complete . . .");
        }

        private static Book GenerateBook()
            => new Book(GenerateDouble(0, 20), GetTitle(rnd.Next(3, 16)),
                (short)rnd.Next(1980, 2030), (short)rnd.Next(0, 701), GenerateDouble(-2, 7));

        private static double GenerateDouble(int min, int max)
            => rnd.Next(min, max) + rnd.NextDouble();

        /// <summary>
        /// This method generates random title for book
        /// </summary>
        /// <param name="length"></param>
        /// <returns></returns>
        private static string GetTitle(int length)
        {
            string result = "",
                charCollection = " QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnm";
            for (int i = 0; i < length; i++)
                result += charCollection[rnd.Next(0, charCollection.Length)];

            return result;
        }

        /// <summary>
        /// This method gets an integer number from user
        /// </summary>
        /// <param name="message"></param>
        /// <param name="lowerBound"></param>
        /// <param name="upperBound"></param>
        /// <returns></returns>
        public static int GetInt(string message = "Input N: ", int lowerBound = 0, int upperBound = 100000)
        {
            int number;
            Console.Write(message);
            while (!int.TryParse(Console.ReadLine(), out number)
                || number < lowerBound || number > upperBound)
                Console.WriteLine($"Please input integer number in [{lowerBound}, {upperBound}]");
            return number;
        }


    }
}
