﻿using BookstoreLibrary;
using System;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Json;

namespace ConsoleApp2
{
    public class Program
    {
        private const string FilePath = "../../../books.json";

        public static void Main()
        {
            do
            {
                Console.Clear();
                try
                {
                    Bookstore<Product> books = JSONDeserialization(FilePath);
                    foreach (var product in books)
                        Console.WriteLine(product);

                    var linq1 = from book in books
                                where book is Book && (book as Book).GetShortInfo().Length > 14
                                orderby book descending
                                select book;

                    short maxYear = (from book in books
                                     where book is Book
                                     select (book as Book).Year).Max();
                    var linq3 = from book in books
                                where book is Book && (book as Book).Year == maxYear
                                select book;

                    Console.WriteLine("----------\nLinq 1:");
                    foreach (var item in linq1)
                        Console.WriteLine(item);
                    Console.WriteLine("----------\nLinq 2:");
                    var linq2 = books.Where(x => x is Book)
                                     .OrderBy(x => (int)(x as Book).Rating)
                                     .GroupBy(x => (int)(x as Book).Rating);
                    foreach (var groups in linq2)
                    {
                        var sortedLinq2 = groups.Where(x => x is Book).OrderBy(x => (double)x).ToList();
                        foreach (var book in sortedLinq2)
                            Console.WriteLine(book.ToString());
                    }
                    Console.WriteLine("----------\nLinq 3:");
                    foreach (var item in linq3)
                        Console.WriteLine(item);
                    Console.WriteLine($"Count = {linq3.Count()}");

                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }

                Console.WriteLine("\n\nTo exit press Escape key\nTo continue press any key . . .");
            } while (Console.ReadKey().Key != ConsoleKey.Escape);
        }


        /// <summary>
        /// This method deserialize json document and casts type to Bookstore<Product>
        /// </summary>
        /// <param name="path"></param>
        /// <returns></returns>
        private static Bookstore<Product> JSONDeserialization(string path)
        {
            Bookstore<Product> result;
            var formatter = new DataContractJsonSerializer(typeof(Bookstore<Product>), new Type[] { typeof(Product), typeof(Book), });
            using (var fs = new FileStream(path, FileMode.Open))
                result = (Bookstore<Product>)formatter.ReadObject(fs);

            Console.WriteLine("Deserialization comlete . . .");

            return result;
        }



    }
}
